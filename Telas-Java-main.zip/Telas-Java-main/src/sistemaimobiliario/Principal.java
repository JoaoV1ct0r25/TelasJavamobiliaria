package sistemaimobiliario;

public class Principal {
    public static void main(String[] args) {
        new TelaLogin().setVisible(true);
    }
}
