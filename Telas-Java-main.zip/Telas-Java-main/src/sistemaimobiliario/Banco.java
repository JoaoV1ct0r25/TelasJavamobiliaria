package sistemaimobiliario;

import java.util.ArrayList;

public class Banco {
    public static ArrayList<Pessoa> pessoas = new ArrayList<>();
}
